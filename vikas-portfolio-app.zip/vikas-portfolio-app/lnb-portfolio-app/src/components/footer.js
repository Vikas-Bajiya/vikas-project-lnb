import React from 'react'
import './footer.css'

export default function footer() {
  return (
  <footer className='footer'>
    Copyright @ 2024 Nikhil Kumar. All Right Reserved.
  </footer>
  )
}
